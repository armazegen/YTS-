package com.shortsai.app.utils

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

object PermissionUtils {

    // Permission request codes
    const val REQUEST_STORAGE_PERMISSION = 1001
    const val REQUEST_ALL_PERMISSIONS = 1002

    // ==========================================
    // PERMISSION LISTS
    // ==========================================

    /**
     * Get required permissions based on Android version
     */
    fun getRequiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_IMAGES
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10-12
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
        } else {
            // Android 9 and below
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
    }

    // ==========================================
    // PERMISSION CHECKS
    // ==========================================

    /**
     * Check if all required permissions are granted
     */
    fun hasStoragePermissions(context: Context): Boolean {
        return getRequiredPermissions().all { permission ->
            ContextCompat.checkSelfPermission(
                context,
                permission
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Check internet permission
     */
    fun hasInternetPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.INTERNET
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Check single permission
     */
    fun hasPermission(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    // ==========================================
    // PERMISSION REQUESTS
    // ==========================================

    /**
     * Request storage permissions from Activity
     */
    fun requestStoragePermissions(activity: Activity) {
        ActivityCompat.requestPermissions(
            activity,
            getRequiredPermissions(),
            REQUEST_STORAGE_PERMISSION
        )
    }

    /**
     * Request storage permissions from Fragment
     */
    fun requestStoragePermissions(fragment: Fragment) {
        fragment.requestPermissions(
            getRequiredPermissions(),
            REQUEST_STORAGE_PERMISSION
        )
    }

    /**
     * Check if should show rationale
     */
    fun shouldShowRationale(activity: Activity): Boolean {
        return getRequiredPermissions().any { permission ->
            ActivityCompat.shouldShowRequestPermissionRationale(
                activity,
                permission
            )
        }
    }

    // ==========================================
    // RESULT PROCESSING
    // ==========================================

    /**
     * Process permission result
     */
    fun processPermissionResult(
        grantResults: IntArray
    ): Boolean {
        return grantResults.isNotEmpty() &&
                grantResults.all { it == PackageManager.PERMISSION_GRANTED }
    }
}