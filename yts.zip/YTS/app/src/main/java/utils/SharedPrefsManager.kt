package com.shortsai.app.utils

import android.content.Context
import android.content.SharedPreferences

class SharedPrefsManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        Constants.Prefs.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    // ==========================================
    // API KEY
    // ==========================================

    fun saveApiKey(apiKey: String) {
        prefs.edit().putString(Constants.Prefs.KEY_API_KEY, apiKey).apply()
    }

    fun getApiKey(): String {
        return prefs.getString(
            Constants.Prefs.KEY_API_KEY,
            Constants.OPENAI_API_KEY      // Default from Constants
        ) ?: Constants.OPENAI_API_KEY
    }

    fun hasApiKey(): Boolean {
        val key = getApiKey()
        return key.isNotEmpty() && key != "sk-YOUR_OPENAI_API_KEY_HERE"
    }

    // ==========================================
    // VIDEO COUNT
    // ==========================================

    fun incrementVideoCount() {
        val current = getVideoCount()
        prefs.edit().putInt(
            Constants.Prefs.KEY_VIDEO_COUNT,
            current + 1
        ).apply()
    }

    fun getVideoCount(): Int {
        return prefs.getInt(Constants.Prefs.KEY_VIDEO_COUNT, 0)
    }

    // ==========================================
    // LAST TOPIC
    // ==========================================

    fun saveLastTopic(topic: String) {
        prefs.edit().putString(
            Constants.Prefs.KEY_LAST_TOPIC,
            topic
        ).apply()
    }

    fun getLastTopic(): String {
        return prefs.getString(Constants.Prefs.KEY_LAST_TOPIC, "") ?: ""
    }

    // ==========================================
    // CLEAR ALL
    // ==========================================

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}