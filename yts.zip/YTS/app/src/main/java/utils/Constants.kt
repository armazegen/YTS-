package com.shortsai.app.utils

object Constants {

    // ==========================================
    // API CONFIGURATION
    // ==========================================
    const val OPENAI_BASE_URL = "https://api.openai.com/v1/"

    // Replace with your actual API key
    // Get from: https://platform.openai.com/api-keys
    const val OPENAI_API_KEY = "sk-YOUR_OPENAI_API_KEY_HERE"

    // ==========================================
    // OPENAI MODEL SETTINGS
    // ==========================================
    const val GPT_MODEL = "gpt-4o-mini"           // Cost effective
    const val GPT_MODEL_PRO = "gpt-4o"             // Higher quality
    const val DALLE_MODEL = "dall-e-3"             // Image generation
    const val TTS_MODEL = "tts-1"                  // Text to speech
    const val TTS_VOICE = "alloy"                  // Voice type
    // Available voices: alloy, echo, fable, onyx, nova, shimmer

    // ==========================================
    // VIDEO SETTINGS
    // ==========================================
    const val VIDEO_WIDTH = 1080                   // 9:16 portrait
    const val VIDEO_HEIGHT = 1920
    const val VIDEO_FPS = 30
    const val VIDEO_DURATION_PER_SCENE = 5         // seconds per scene
    const val MIN_SCENES = 6
    const val MAX_SCENES = 10
    const val TOTAL_VIDEO_DURATION = 30            // target seconds

    // ==========================================
    // IMAGE SETTINGS
    // ==========================================
    const val IMAGE_SIZE = "1024x1792"             // 9:16 portrait for DALL-E
    const val IMAGE_QUALITY = "standard"           // standard or hd
    const val IMAGE_STYLE = "vivid"                // vivid or natural

    // ==========================================
    // FILE SETTINGS
    // ==========================================
    const val APP_FOLDER = "YouTubeShortsAI"
    const val TEMP_FOLDER = "temp"
    const val OUTPUT_FOLDER = "output"
    const val IMAGES_FOLDER = "images"
    const val AUDIO_FOLDER = "audio"

    // File Extensions
    const val VIDEO_EXTENSION = ".mp4"
    const val IMAGE_EXTENSION = ".jpg"
    const val AUDIO_EXTENSION = ".mp3"

    // ==========================================
    // NETWORK SETTINGS
    // ==========================================
    const val CONNECTION_TIMEOUT = 120L            // seconds
    const val READ_TIMEOUT = 120L
    const val WRITE_TIMEOUT = 120L

    // ==========================================
    // SCRIPT GENERATION PROMPT
    // ==========================================
    fun getScriptPrompt(topic: String): String {
        return """
            You are a viral YouTube Shorts scriptwriter.
            
            Create a compelling script for a YouTube Short about: "$topic"
            
            Requirements:
            - Total duration: 30-45 seconds when spoken
            - Word count: 80-120 words
            - Style: Engaging, fast-paced, hook-first
            - Start with a powerful hook (first 3 seconds)
            - Include a call to action at the end
            
            Return ONLY a valid JSON object with this exact structure:
            {
                "title": "Video title here",
                "hook": "Opening hook line",
                "script": "Full script text here",
                "scenes": [
                    {
                        "scene_number": 1,
                        "duration": 5,
                        "narration": "Text spoken in this scene",
                        "visual_description": "Detailed image prompt for AI image generation",
                        "on_screen_text": "Text shown on screen"
                    }
                ],
                "hashtags": ["#tag1", "#tag2", "#tag3"],
                "call_to_action": "Subscribe for more!"
            }
            
            Generate exactly 6-8 scenes.
            Make visual_description very detailed for DALL-E image generation.
            Do not include any text outside the JSON object.
        """.trimIndent()
    }

    // ==========================================
    // IMAGE PROMPT ENHANCER
    // ==========================================
    fun enhanceImagePrompt(basePrompt: String): String {
        return """
            $basePrompt
            
            Style requirements:
            - Cinematic quality, 8K resolution
            - Vibrant colors, high contrast
            - Professional photography style
            - Vertical composition (9:16 aspect ratio)
            - No text or watermarks in image
            - Ultra realistic or artistic style
        """.trimIndent()
    }

    // ==========================================
    // ERROR MESSAGES
    // ==========================================
    object Errors {
        const val NETWORK_ERROR = "Network error. Please check your internet connection."
        const val API_KEY_ERROR = "Invalid API key. Please check your OpenAI API key."
        const val QUOTA_ERROR = "API quota exceeded. Please check your OpenAI account."
        const val PERMISSION_ERROR = "Storage permission denied. Cannot save video."
        const val FFMPEG_ERROR = "Video processing failed. Please try again."
        const val UNKNOWN_ERROR = "Something went wrong. Please try again."
        const val TIMEOUT_ERROR = "Request timed out. Please try again."
    }

    // ==========================================
    // PROGRESS STEPS
    // ==========================================
    object Progress {
        const val STEP_SCRIPT = 10
        const val STEP_IMAGES_START = 20
        const val STEP_IMAGES_END = 60
        const val STEP_AUDIO = 70
        const val STEP_VIDEO_BUILD = 85
        const val STEP_COMPLETE = 100

        const val MSG_SCRIPT = "✍️ Writing viral script..."
        const val MSG_IMAGES = "🎨 Creating AI images..."
        const val MSG_AUDIO = "🎤 Generating voiceover..."
        const val MSG_VIDEO = "🎬 Building your video..."
        const val MSG_SAVING = "💾 Saving to gallery..."
        const val MSG_COMPLETE = "✅ Your Short is ready!"
    }

    // ==========================================
    // SHARED PREFS KEYS
    // ==========================================
    object Prefs {
        const val PREFS_NAME = "ShortsAIPrefs"
        const val KEY_API_KEY = "openai_api_key"
        const val KEY_VIDEO_COUNT = "total_videos_generated"
        const val KEY_LAST_TOPIC = "last_topic"
    }
}