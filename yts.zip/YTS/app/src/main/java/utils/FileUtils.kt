package com.shortsai.app.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

object FileUtils {

    private const val TAG = "FileUtils"

    // ==========================================
    // DIRECTORY SETUP
    // ==========================================

    /**
     * Get or create app's temp directory
     */
    fun getTempDir(context: Context): File {
        val dir = File(
            context.cacheDir,
            "${Constants.APP_FOLDER}/${Constants.TEMP_FOLDER}"
        )
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Get images directory
     */
    fun getImagesDir(context: Context): File {
        val dir = File(getTempDir(context), Constants.IMAGES_FOLDER)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Get audio directory
     */
    fun getAudioDir(context: Context): File {
        val dir = File(getTempDir(context), Constants.AUDIO_FOLDER)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Get output directory
     */
    fun getOutputDir(context: Context): File {
        val dir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            Constants.APP_FOLDER
        )
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // ==========================================
    // FILE NAME GENERATORS
    // ==========================================

    fun generateVideoFileName(): String {
        val timestamp = SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.getDefault()
        ).format(Date())
        return "SHORT_${timestamp}${Constants.VIDEO_EXTENSION}"
    }

    fun generateImageFileName(sceneIndex: Int): String {
        return "scene_${sceneIndex.toString().padStart(3, '0')}${Constants.IMAGE_EXTENSION}"
    }

    fun generateAudioFileName(): String {
        return "voiceover${Constants.AUDIO_EXTENSION}"
    }

    // ==========================================
    // IMAGE OPERATIONS
    // ==========================================

    /**
     * Download image from URL and save to file
     */
    suspend fun downloadImageToFile(
        imageUrl: String,
        destFile: File,
        onProgress: ((Int) -> Unit)? = null
    ): Boolean {
        return try {
            val url = URL(imageUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.apply {
                connectTimeout = 30000
                readTimeout = 30000
                requestMethod = "GET"
                connect()
            }

            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "Failed to download: ${connection.responseCode}")
                return false
            }

            val inputStream = BufferedInputStream(connection.inputStream)
            val outputStream = FileOutputStream(destFile)

            val buffer = ByteArray(8192)
            var bytesRead: Int
            var totalBytesRead = 0L
            val fileSize = connection.contentLength.toLong()

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                totalBytesRead += bytesRead
                if (fileSize > 0) {
                    val progress = ((totalBytesRead * 100) / fileSize).toInt()
                    onProgress?.invoke(progress)
                }
            }

            outputStream.flush()
            outputStream.close()
            inputStream.close()
            connection.disconnect()

            Log.d(TAG, "Image downloaded: ${destFile.absolutePath}")
            true

        } catch (e: Exception) {
            Log.e(TAG, "Download failed: ${e.message}")
            false
        }
    }

    /**
     * Save bitmap to file as JPEG
     */
    fun saveBitmapToFile(bitmap: Bitmap, file: File): Boolean {
        return try {
            FileOutputStream(file).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
                fos.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save bitmap: ${e.message}")
            false
        }
    }

    /**
     * Resize image to video dimensions
     */
    fun resizeImageForVideo(
        sourceFile: File,
        targetFile: File,
        width: Int = Constants.VIDEO_WIDTH,
        height: Int = Constants.VIDEO_HEIGHT
    ): Boolean {
        return try {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(sourceFile.absolutePath, options)

            val sampleSize = calculateSampleSize(
                options.outWidth,
                options.outHeight,
                width,
                height
            )

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
            }

            val bitmap = BitmapFactory.decodeFile(
                sourceFile.absolutePath,
                decodeOptions
            ) ?: return false

            val resized = Bitmap.createScaledBitmap(bitmap, width, height, true)
            val result = saveBitmapToFile(resized, targetFile)

            bitmap.recycle()
            resized.recycle()

            result
        } catch (e: Exception) {
            Log.e(TAG, "Resize failed: ${e.message}")
            false
        }
    }

    private fun calculateSampleSize(
        srcWidth: Int,
        srcHeight: Int,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        var sampleSize = 1
        if (srcWidth > reqWidth || srcHeight > reqHeight) {
            val halfWidth = srcWidth / 2
            val halfHeight = srcHeight / 2
            while (halfWidth / sampleSize >= reqWidth
                && halfHeight / sampleSize >= reqHeight) {
                sampleSize *= 2
            }
        }
        return sampleSize
    }

    // ==========================================
    // AUDIO OPERATIONS
    // ==========================================

    /**
     * Save audio bytes to file
     */
    fun saveAudioToFile(audioBytes: ByteArray, file: File): Boolean {
        return try {
            FileOutputStream(file).use { fos ->
                fos.write(audioBytes)
                fos.flush()
            }
            Log.d(TAG, "Audio saved: ${file.absolutePath}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save audio: ${e.message}")
            false
        }
    }

    // ==========================================
    // VIDEO SAVE TO GALLERY
    // ==========================================

    /**
     * Save video to device gallery (MediaStore)
     */
    fun saveVideoToGallery(
        context: Context,
        videoFile: File
    ): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ use MediaStore
                saveVideoMediaStore(context, videoFile)
            } else {
                // Android 9 and below
                saveVideoLegacy(context, videoFile)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save video to gallery: ${e.message}")
            null
        }
    }

    private fun saveVideoMediaStore(
        context: Context,
        videoFile: File
    ): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, videoFile.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                "${Environment.DIRECTORY_MOVIES}/${Constants.APP_FOLDER}"
            )
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }

        val uri = context.contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            values
        ) ?: return null

        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
            FileInputStream(videoFile).use { inputStream ->
                inputStream.copyTo(outputStream)
            }
        }

        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        context.contentResolver.update(uri, values, null, null)

        Log.d(TAG, "Video saved to MediaStore: $uri")
        return uri
    }

    private fun saveVideoLegacy(
        context: Context,
        videoFile: File
    ): Uri? {
        val moviesDir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_MOVIES
        )
        val appDir = File(moviesDir, Constants.APP_FOLDER)
        if (!appDir.exists()) appDir.mkdirs()

        val destFile = File(appDir, videoFile.name)
        videoFile.copyTo(destFile, overwrite = true)

        // Notify media scanner
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DATA, destFile.absolutePath)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.TITLE, destFile.nameWithoutExtension)
        }

        return context.contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            values
        )
    }

    // ==========================================
    // CLEANUP OPERATIONS
    // ==========================================

    /**
     * Delete all temp files after video creation
     */
    fun cleanupTempFiles(context: Context) {
        try {
            val tempDir = getTempDir(context)
            deleteRecursively(tempDir)
            Log.d(TAG, "Temp files cleaned up")
        } catch (e: Exception) {
            Log.e(TAG, "Cleanup failed: ${e.message}")
        }
    }

    private fun deleteRecursively(file: File) {
        if (file.isDirectory) {
            file.listFiles()?.forEach { deleteRecursively(it) }
        }
        file.delete()
    }

    /**
     * Get file size in MB
     */
    fun getFileSizeMB(file: File): Double {
        return file.length() / (1024.0 * 1024.0)
    }

    /**
     * Check if file exists and is valid
     */
    fun isValidFile(file: File?): Boolean {
        return file != null && file.exists() && file.length() > 0
    }
}