package com.shortsai.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.shortsai.app.R
import com.shortsai.app.api.models.GenerationState
import com.shortsai.app.databinding.FragmentHomeBinding
import com.shortsai.app.utils.Constants
import com.shortsai.app.viewmodel.VideoViewModel
import com.shortsai.app.viewmodel.VideoViewModelFactory

class HomeFragment : Fragment() {

    // ==========================================
    // VIEW BINDING
    // ==========================================

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    // ==========================================
    // VIEW MODEL
    // ==========================================

    private val viewModel: VideoViewModel by activityViewModels {
        VideoViewModelFactory(requireContext())
    }

    // ==========================================
    // LIFECYCLE
    // ==========================================

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()
        setupSuggestionChips()
        setupHowItWorks()
        observeViewModel()
        loadStats()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // ==========================================
    // UI SETUP
    // ==========================================

    private fun setupUI() {

        // Generate button click
        binding.btnGenerate.setOnClickListener {
            val topic = binding.etTopic.text
                .toString()
                .trim()
            hideKeyboard()
            startGeneration(topic)
        }

        // Cancel button click
        binding.btnCancel.setOnClickListener {
            viewModel.cancelGeneration()
            showIdleState()
            Toast.makeText(
                requireContext(),
                "Generation cancelled",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Done on keyboard
        binding.etTopic.setOnEditorActionListener {
                _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val topic = binding.etTopic.text
                    .toString().trim()
                hideKeyboard()
                startGeneration(topic)
                true
            } else {
                false
            }
        }

        // Restore last topic
        val lastTopic = viewModel.getLastTopic()
        if (lastTopic.isNotEmpty()) {
            binding.etTopic.setText(lastTopic)
            binding.etTopic.setSelection(lastTopic.length)
        }
    }

    // ==========================================
    // SUGGESTION CHIPS SETUP
    // ==========================================

    private fun setupSuggestionChips() {
        val suggestions = listOf(
            "🧠 Mind-blowing facts",
            "💰 Make money online",
            "🌍 World wonders",
            "🤖 Future of AI",
            "🏋️ Fitness tips"
        )

        val chips = listOf(
            binding.chip1,
            binding.chip2,
            binding.chip3,
            binding.chip4,
            binding.chip5
        )

        chips.forEachIndexed { index, chip ->
            if (index < suggestions.size) {
                chip.text = suggestions[index]
                chip.setOnClickListener {
                    // Set topic from chip
                    val cleanText = suggestions[index]
                        .replace(Regex("[^a-zA-Z0-9 ]"), "")
                        .trim()
                    binding.etTopic.setText(cleanText)
                    binding.etTopic.setSelection(cleanText.length)

                    // Animate chip selection
                    chip.isChecked = true

                    // Auto scroll to generate button
                    binding.root.post {
                        binding.btnGenerate.requestFocus()
                    }
                }
            }
        }
    }

    // ==========================================
    // HOW IT WORKS SETUP
    // ==========================================

    private fun setupHowItWorks() {
        val steps = listOf(
            Triple("✍️", "Script Generation", "GPT-4 writes viral script"),
            Triple("🎨", "AI Image Creation", "DALL-E creates scene visuals"),
            Triple("🎤", "Voice Generation", "TTS creates voiceover"),
            Triple("🎬", "Video Building", "FFmpeg compiles final video")
        )

        val stepViews = listOf(
            binding.howStep1,
            binding.howStep2,
            binding.howStep3,
            binding.howStep4
        )

        stepViews.forEachIndexed { index, stepView ->
            if (index < steps.size) {
                val (emoji, title, desc) = steps[index]
                stepView.findViewById<TextView>(
                    R.id.tv_step_emoji
                ).text = emoji
                stepView.findViewById<TextView>(
                    R.id.tv_step_title
                ).text = title
                stepView.findViewById<TextView>(
                    R.id.tv_step_desc
                ).text = desc
            }
        }
    }

    // ==========================================
    // START GENERATION
    // ==========================================

    private fun startGeneration(topic: String) {
        if (topic.isEmpty()) {
            binding.tilTopic.error = "Please enter a topic"
            return
        }

        binding.tilTopic.error = null

        // Check API key
        if (!viewModel.hasValidApiKey()) {
            Toast.makeText(
                requireContext(),
                "⚠️ Please set your OpenAI API key in Settings first!",
                Toast.LENGTH_LONG
            ).show()
            findNavController().navigate(
                R.id.action_home_to_settings
            )
            return
        }

        // Start generation
        showProgressState()
        viewModel.generateVideo(topic)
    }

    // ==========================================
    // OBSERVE VIEW MODEL
    // ==========================================

    private fun observeViewModel() {

        // Generation state
        viewModel.generationState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is GenerationState.Idle -> {
                    showIdleState()
                }

                is GenerationState.Loading -> {
                    showProgressState()
                    updateProgress(
                        state.progress,
                        state.message
                    )
                }

                is GenerationState.Success -> {
                    showIdleState()
                    // Navigate to preview
                    navigateToPreview()
                }

                is GenerationState.Error -> {
                    showIdleState()
                    showError(state.message)
                }
            }
        }

        // Progress updates
        viewModel.progress.observe(viewLifecycleOwner) { progress ->
            binding.progressBar.progress = progress
            binding.tvProgressPercent.text = "$progress%"
            updateStepIcons(progress)
        }

        // Progress message
        viewModel.progressMessage.observe(viewLifecycleOwner) { message ->
            binding.tvProgressMessage.text = message
        }

        // Toast messages
        viewModel.toastMessage.observe(viewLifecycleOwner) { message ->
            if (message.isNotEmpty()) {
                Toast.makeText(
                    requireContext(),
                    message,
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // ==========================================
    // UPDATE PROGRESS UI
    // ==========================================

    private fun updateProgress(progress: Int, message: String) {
        binding.progressBar.setProgressCompat(progress, true)
        binding.tvProgressPercent.text = "$progress%"
        binding.tvProgressMessage.text = message
        updateStepIcons(progress)
    }

    private fun updateStepIcons(progress: Int) {
        // Script step
        binding.stepScriptIcon.text = when {
            progress >= Constants.Progress.STEP_SCRIPT -> "✅"
            progress > 0 -> "⏳"
            else -> "⬜"
        }

        // Images step
        binding.stepImagesIcon.text = when {
            progress >= Constants.Progress.STEP_IMAGES_END -> "✅"
            progress >= Constants.Progress.STEP_IMAGES_START -> "⏳"
            else -> "⬜"
        }

        // Audio step
        binding.stepAudioIcon.text = when {
            progress >= Constants.Progress.STEP_AUDIO + 10 -> "✅"
            progress >= Constants.Progress.STEP_AUDIO -> "⏳"
            else -> "⬜"
        }

        // Video step
        binding.stepVideoIcon.text = when {
            progress >= Constants.Progress.STEP_COMPLETE -> "✅"
            progress >= Constants.Progress.STEP_VIDEO_BUILD -> "⏳"
            else -> "⬜"
        }
    }

    // ==========================================
    // STATE UI HELPERS
    // ==========================================

    private fun showIdleState() {
        binding.apply {
            btnGenerate.isEnabled = true
            btnGenerate.text = getString(R.string.generate_btn)
            cardProgress.visibility = View.GONE
            cardHowItWorks.visibility = View.VISIBLE
            layoutStats.visibility = View.VISIBLE
            progressBar.progress = 0
            tvProgressPercent.text = "0%"
        }
        loadStats()
    }

    private fun showProgressState() {
        binding.apply {
            btnGenerate.isEnabled = false
            btnGenerate.text = "⏳ Generating..."
            cardProgress.visibility = View.VISIBLE
            cardHowItWorks.visibility = View.GONE
            layoutStats.visibility = View.GONE

            // Reset step icons
            stepScriptIcon.text = "⏳"
            stepImagesIcon.text = "⬜"
            stepAudioIcon.text = "⬜"
            stepVideoIcon.text = "⬜"
        }
    }

    private fun showError(message: String) {
        Toast.makeText(
            requireContext(),
            "❌ $message",
            Toast.LENGTH_LONG
        ).show()
        showIdleState()
    }

    // ==========================================
    // NAVIGATE TO PREVIEW
    // ==========================================

    private fun navigateToPreview() {
        try {
            findNavController().navigate(
                R.id.action_home_to_preview
            )
        } catch (e: Exception) {
            Toast.makeText(
                requireContext(),
                "✅ Video created! Check Preview tab",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ==========================================
    // LOAD STATS
    // ==========================================

    private fun loadStats() {
        binding.tvVideoCount.text = viewModel.getVideoCount().toString()
    }

    // ==========================================
    // KEYBOARD
    // ==========================================

    private fun hideKeyboard() {
        val imm = ContextCompat.getSystemService(
            requireContext(),
            InputMethodManager::class.java
        )
        imm?.hideSoftInputFromWindow(
            binding.etTopic.windowToken,
            0
        )
    }
}