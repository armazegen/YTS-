package com.shortsai.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.shortsai.app.databinding.FragmentSettingsBinding
import com.shortsai.app.viewmodel.SettingsViewModel

class SettingsFragment : Fragment() {

    // ==========================================
    // VIEW BINDING
    // ==========================================

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    // ==========================================
    // VIEW MODEL
    // ==========================================

    private val viewModel: SettingsViewModel by viewModels {
        SettingsViewModel.Factory(requireContext())
    }

    // ==========================================
    // LIFECYCLE
    // ==========================================

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(
            inflater,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()
        observeViewModel()
        loadCurrentSettings()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // ==========================================
    // UI SETUP
    // ==========================================

    private fun setupUI() {

        // Save API Key button
        binding.btnSaveKey.setOnClickListener {
            val key = binding.etApiKey.text
                .toString().trim()
            viewModel.saveApiKey(key)
        }

        // Clear data button
        binding.btnClearData.setOnClickListener {
            showClearDataConfirmation()
        }
    }

    // ==========================================
    // OBSERVE VIEW MODEL
    // ==========================================

    private fun observeViewModel() {

        // API key
        viewModel.apiKey.observe(viewLifecycleOwner) { key ->
            if (key.isNotEmpty() && key != "sk-YOUR_OPENAI_API_KEY_HERE") {
                // Show masked key
                val masked = maskApiKey(key)
                binding.etApiKey.setText(masked)
                binding.tvApiStatus.text = "✅ Set"
                binding.tvApiStatus.setTextColor(
                    resources.getColor(
                        com.shortsai.app.R.color.success,
                        null
                    )
                )
            } else {
                binding.tvApiStatus.text = "❌ Not Set"
                binding.tvApiStatus.setTextColor(
                    resources.getColor(
                        com.shortsai.app.R.color.error,
                        null
                    )
                )
            }
        }

        // Save result
        viewModel.saveResult.observe(viewLifecycleOwner) { (success, message) ->
            Toast.makeText(
                requireContext(),
                if (success) "✅ $message" else "❌ $message",
                Toast.LENGTH_SHORT
            ).show()

            if (success) {
                // Clear input field
                binding.etApiKey.text?.clear()
            }
        }

        // Video count
        viewModel.videoCount.observe(viewLifecycleOwner) { count ->
            binding.tvTotalVideos.text = count.toString()
        }
    }

    // ==========================================
    // LOAD CURRENT SETTINGS
    // ==========================================

    private fun loadCurrentSettings() {
        // Trigger LiveData updates
        viewModel.apiKey.value?.let { key ->
            if (key.isNotEmpty()) {
                binding.tvApiStatus.text = "✅ Set"
            }
        }
    }

    // ==========================================
    // CLEAR DATA CONFIRMATION
    // ==========================================

    private fun showClearDataConfirmation() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Clear All Data")
            .setMessage(
                "This will remove your API key and all settings. " +
                        "Are you sure?"
            )
            .setPositiveButton("Clear") { _, _ ->
                viewModel.clearAllData()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ==========================================
    // MASK API KEY
    // ==========================================

    private fun maskApiKey(key: String): String {
        return if (key.length > 8) {
            key.take(7) + "..." + key.takeLast(4)
        } else {
            "***"
        }
    }
}