package com.shortsai.app.video

import android.content.Context
import android.util.Log
import com.shortsai.app.api.models.SceneData
import com.shortsai.app.utils.Constants
import com.shortsai.app.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class VideoBuilder(
    private val context: Context,
    private val ffmpeg: FFmpegProcessor
) {

    private val TAG = "VideoBuilder"

    // ==========================================
    // MAIN BUILD VIDEO
    // ==========================================

    /**
     * Complete video building pipeline:
     * Images + Audio → Final MP4
     *
     * Steps:
     * 1. Resize all images to video dimensions
     * 2. Create slideshow from images
     * 3. Merge audio with slideshow
     * 4. Add subtitle overlays
     * 5. Add fade effects
     * 6. Validate final output
     */
    suspend fun buildVideo(
        imagePaths: List<String>,
        audioPath: String,
        outputPath: String,
        scenes: List<SceneData>,
        onProgress: (Int, String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {

        Log.d(TAG, "========================================")
        Log.d(TAG, "VideoBuilder.buildVideo() started")
        Log.d(TAG, "Images: ${imagePaths.size}")
        Log.d(TAG, "Audio: $audioPath")
        Log.d(TAG, "Output: $outputPath")
        Log.d(TAG, "========================================")

        val tempDir = FileUtils.getTempDir(context)

        // ==============================
        // STEP 1: RESIZE IMAGES
        // ==============================

        onProgress(10, "📐 Preparing images...")
        Log.d(TAG, "Step 1: Resizing images")

        val resizedPaths = resizeAllImages(imagePaths, tempDir)

        if (resizedPaths.isEmpty()) {
            Log.e(TAG, "No images after resize")
            return@withContext false
        }

        Log.d(TAG, "Resized: ${resizedPaths.size} images")

        // ==============================
        // STEP 2: CREATE SLIDESHOW
        // ==============================

        onProgress(20, "🎬 Creating slideshow...")
        Log.d(TAG, "Step 2: Creating slideshow")

        val slideshowPath = File(tempDir, "slideshow.mp4").absolutePath

        // Calculate duration per image based on audio
        val audioDurationMs = ffmpeg.getMediaDuration(audioPath)
        val audioDurationSecs = (audioDurationMs / 1000).toInt()
        val durationPerImage = calculateDurationPerImage(
            imageCount = resizedPaths.size,
            totalDuration = audioDurationSecs
        )

        Log.d(TAG, "Audio duration: ${audioDurationSecs}s")
        Log.d(TAG, "Duration per image: ${durationPerImage}s")

        // Try Ken Burns effect first, fallback to simple slideshow
        val slideshowCreated = if (resizedPaths.size <= 8) {
            // Ken Burns for small number of images
            Log.d(TAG, "Using Ken Burns effect")
            ffmpeg.createSlideshowWithKenBurns(
                imagePaths = resizedPaths,
                outputPath = slideshowPath,
                durationPerImage = durationPerImage,
                fps = Constants.VIDEO_FPS,
                onProgress = { frame ->
                    val progress = 20 + ((frame.toFloat() / 100) * 30).toInt()
                    onProgress(
                        progress.coerceIn(20, 50),
                        "🎨 Processing frames..."
                    )
                }
            )
        } else {
            // Simple slideshow for many images
            Log.d(TAG, "Using simple slideshow")
            ffmpeg.createSlideshow(
                imagePaths = resizedPaths,
                outputPath = slideshowPath,
                durationPerImage = durationPerImage,
                fps = Constants.VIDEO_FPS,
                onProgress = { frame ->
                    val progress = 20 + ((frame.toFloat() / 100) * 30).toInt()
                    onProgress(
                        progress.coerceIn(20, 50),
                        "🎬 Building slideshow..."
                    )
                }
            )
        }

        if (!slideshowCreated || !FileUtils.isValidFile(File(slideshowPath))) {
            Log.e(TAG, "Slideshow creation failed")
            // Fallback to simple slideshow
            Log.d(TAG, "Trying simple slideshow fallback")
            val fallbackResult = ffmpeg.createSlideshow(
                imagePaths = resizedPaths,
                outputPath = slideshowPath,
                durationPerImage = durationPerImage,
                fps = Constants.VIDEO_FPS
            )
            if (!fallbackResult) {
                Log.e(TAG, "Fallback slideshow also failed")
                return@withContext false
            }
        }

        Log.d(TAG, "Slideshow created: $slideshowPath")

        // ==============================
        // STEP 3: MERGE AUDIO
        // ==============================

        onProgress(55, "🎤 Adding voiceover...")
        Log.d(TAG, "Step 3: Merging audio")

        val videoWithAudioPath = File(
            tempDir,
            "video_with_audio.mp4"
        ).absolutePath

        val audioMerged = ffmpeg.addAudioToVideo(
            videoPath = slideshowPath,
            audioPath = audioPath,
            outputPath = videoWithAudioPath,
            onProgress = { frame ->
                val progress = 55 + ((frame.toFloat() / 100) * 15).toInt()
                onProgress(
                    progress.coerceIn(55, 70),
                    "🔊 Merging audio..."
                )
            }
        )

        if (!audioMerged || !FileUtils.isValidFile(File(videoWithAudioPath))) {
            Log.e(TAG, "Audio merge failed")
            return@withContext false
        }

        Log.d(TAG, "Audio merged: $videoWithAudioPath")

        // ==============================
        // STEP 4: ADD SUBTITLES
        // ==============================

        onProgress(72, "📝 Adding subtitles...")
        Log.d(TAG, "Step 4: Adding subtitles")

        val videoWithSubsPath = File(
            tempDir,
            "video_with_subs.mp4"
        ).absolutePath

        val subtitles = buildSubtitleEntries(scenes, durationPerImage)

        val subsAdded = if (subtitles.isNotEmpty()) {
            ffmpeg.addSubtitlesOverlay(
                videoPath = videoWithAudioPath,
                outputPath = videoWithSubsPath,
                subtitles = subtitles,
                onProgress = { frame ->
                    val progress = 72 + ((frame.toFloat() / 100) * 13).toInt()
                    onProgress(
                        progress.coerceIn(72, 85),
                        "📝 Burning subtitles..."
                    )
                }
            )
        } else {
            // No subtitles - copy file
            File(videoWithAudioPath).copyTo(
                File(videoWithSubsPath),
                overwrite = true
            )
            true
        }

        // Use audio-merged version if subtitle step fails
        val preFadeVideoPath = if (subsAdded &&
            FileUtils.isValidFile(File(videoWithSubsPath))) {
            videoWithSubsPath
        } else {
            Log.w(TAG, "Subtitle step failed, using video without subs")
            videoWithAudioPath
        }

        Log.d(TAG, "Pre-fade video: $preFadeVideoPath")

        // ==============================
        // STEP 5: ADD FADE EFFECTS
        // ==============================

        onProgress(87, "✨ Adding effects...")
        Log.d(TAG, "Step 5: Adding fade effects")

        val videoFinalTempPath = File(
            tempDir,
            "video_final_temp.mp4"
        ).absolutePath

        // Get actual video duration
        val videoDurationMs = ffmpeg.getMediaDuration(preFadeVideoPath)
        val videoDurationSecs = (videoDurationMs / 1000).toInt()

        val fadeAdded = if (videoDurationSecs > 3) {
            ffmpeg.addFadeEffects(
                videoPath = preFadeVideoPath,
                outputPath = videoFinalTempPath,
                totalDurationSecs = videoDurationSecs,
                fadeInDuration = 0.5f,
                fadeOutDuration = 0.8f
            )
        } else {
            // Skip fade for very short videos
            File(preFadeVideoPath).copyTo(
                File(videoFinalTempPath),
                overwrite = true
            )
            true
        }

        val preFinalPath = if (fadeAdded &&
            FileUtils.isValidFile(File(videoFinalTempPath))) {
            videoFinalTempPath
        } else {
            Log.w(TAG, "Fade failed, skipping")
            preFadeVideoPath
        }

        // ==============================
        // STEP 6: COPY TO OUTPUT
        // ==============================

        onProgress(94, "💾 Finalizing video...")
        Log.d(TAG, "Step 6: Copying to output")

        try {
            File(preFinalPath).copyTo(File(outputPath), overwrite = true)
        } catch (e: Exception) {
            Log.e(TAG, "Copy to output failed: ${e.message}")
            return@withContext false
        }

        // ==============================
        // STEP 7: VALIDATE OUTPUT
        // ==============================

        onProgress(97, "🔍 Validating video...")
        Log.d(TAG, "Step 7: Validating output")

        val isValid = ffmpeg.validateVideo(outputPath)

        if (isValid) {
            val outputFile = File(outputPath)
            val sizeMB = FileUtils.getFileSizeMB(outputFile)
            val duration = ffmpeg.getMediaDuration(outputPath) / 1000

            Log.d(TAG, "========================================")
            Log.d(TAG, "✅ VIDEO BUILD COMPLETE!")
            Log.d(TAG, "Output: $outputPath")
            Log.d(TAG, "Size: ${sizeMB}MB")
            Log.d(TAG, "Duration: ${duration}s")
            Log.d(TAG, "========================================")

            onProgress(100, "✅ Video ready!")
        } else {
            Log.e(TAG, "Video validation failed")
        }

        isValid
    }

    // ==========================================
    // RESIZE ALL IMAGES
    // ==========================================

    /**
     * Resize all images to exact video dimensions
     * Ensures consistent video output
     */
    private fun resizeAllImages(
        imagePaths: List<String>,
        tempDir: File
    ): List<String> {

        val resizedDir = File(tempDir, "resized")
        if (!resizedDir.exists()) resizedDir.mkdirs()

        val resizedPaths = mutableListOf<String>()

        imagePaths.forEachIndexed { index, path ->
            val sourceFile = File(path)

            if (!FileUtils.isValidFile(sourceFile)) {
                Log.w(TAG, "Skipping invalid image: $path")
                return@forEachIndexed
            }

            val resizedFile = File(
                resizedDir,
                "resized_${index.toString().padStart(3, '0')}.jpg"
            )

            val success = FileUtils.resizeImageForVideo(
                sourceFile = sourceFile,
                targetFile = resizedFile,
                width = Constants.VIDEO_WIDTH,
                height = Constants.VIDEO_HEIGHT
            )

            if (success && FileUtils.isValidFile(resizedFile)) {
                resizedPaths.add(resizedFile.absolutePath)
                Log.d(TAG, "Resized image $index: ${resizedFile.absolutePath}")
            } else {
                Log.w(TAG, "Resize failed for image $index, using original")
                // Use original if resize fails
                if (FileUtils.isValidFile(sourceFile)) {
                    resizedPaths.add(path)
                }
            }
        }

        Log.d(TAG, "Resize complete: ${resizedPaths.size}/${imagePaths.size}")
        return resizedPaths
    }

    // ==========================================
    // BUILD SUBTITLE ENTRIES
    // ==========================================

    /**
     * Convert scene data to subtitle timing entries
     */
    private fun buildSubtitleEntries(
        scenes: List<SceneData>,
        durationPerImage: Int
    ): List<SubtitleEntry> {

        val subtitles = mutableListOf<SubtitleEntry>()
        var currentTime = 0f

        scenes.forEach { scene ->
            val text = scene.onScreenText.trim()

            if (text.isNotEmpty()) {
                // Split long text into multiple lines
                val lines = splitTextIntoLines(text, maxCharsPerLine = 25)

                lines.forEachIndexed { lineIndex, line ->
                    val lineStart = currentTime + (lineIndex * 1.5f)
                    val lineEnd = minOf(
                        lineStart + 1.5f,
                        currentTime + durationPerImage - 0.5f
                    )

                    if (lineStart < lineEnd) {
                        subtitles.add(
                            SubtitleEntry(
                                text = line,
                                startSecs = lineStart,
                                endSecs = lineEnd
                            )
                        )
                    }
                }
            }

            currentTime += durationPerImage.toFloat()
        }

        Log.d(TAG, "Built ${subtitles.size} subtitle entries")
        return subtitles
    }

    // ==========================================
    // CALCULATE DURATION PER IMAGE
    // ==========================================

    /**
     * Calculate how long each image should show
     * Based on audio duration and image count
     */
    private fun calculateDurationPerImage(
        imageCount: Int,
        totalDuration: Int
    ): Int {
        if (imageCount <= 0) return Constants.VIDEO_DURATION_PER_SCENE

        // Target: fill audio duration evenly
        val calculated = totalDuration / imageCount

        return when {
            calculated < 3 -> 3          // Minimum 3 seconds
            calculated > 10 -> 8         // Maximum 8 seconds
            else -> calculated
        }
    }

    // ==========================================
    // SPLIT TEXT INTO LINES
    // ==========================================

    /**
     * Split long text into shorter lines for subtitles
     */
    private fun splitTextIntoLines(
        text: String,
        maxCharsPerLine: Int = 25
    ): List<String> {

        if (text.length <= maxCharsPerLine) return listOf(text)

        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = StringBuilder()

        words.forEach { word ->
            if (currentLine.length + word.length + 1 <= maxCharsPerLine) {
                if (currentLine.isNotEmpty()) currentLine.append(" ")
                currentLine.append(word)
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine.toString())
                }
                currentLine = StringBuilder(word)
            }
        }

        if (currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
        }

        return lines.take(3) // Max 3 lines
    }
}