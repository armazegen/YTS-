package com.shortsai.app.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.shortsai.app.api.ApiClient
import com.shortsai.app.utils.SharedPrefsManager

class SettingsViewModel(
    private val prefs: SharedPrefsManager
) : ViewModel() {

    // ==========================================
    // LIVE DATA
    // ==========================================

    private val _apiKey = MutableLiveData<String>()
    val apiKey: LiveData<String> = _apiKey

    private val _saveResult = MutableLiveData<Pair<Boolean, String>>()
    val saveResult: LiveData<Pair<Boolean, String>> = _saveResult

    private val _videoCount = MutableLiveData<Int>()
    val videoCount: LiveData<Int> = _videoCount

    // ==========================================
    // INIT
    // ==========================================

    init {
        loadSettings()
    }

    private fun loadSettings() {
        _apiKey.value = prefs.getApiKey()
        _videoCount.value = prefs.getVideoCount()
    }

    // ==========================================
    // SAVE API KEY
    // ==========================================

    fun saveApiKey(key: String) {
        when {
            key.isBlank() -> {
                _saveResult.value = Pair(false, "API key cannot be empty")
            }
            !key.startsWith("sk-") -> {
                _saveResult.value = Pair(
                    false,
                    "Invalid format. Key must start with 'sk-'"
                )
            }
            key.length < 20 -> {
                _saveResult.value = Pair(
                    false,
                    "API key too short"
                )
            }
            else -> {
                prefs.saveApiKey(key)
                ApiClient.updateApiKey(key)
                _apiKey.value = key
                _saveResult.value = Pair(true, "API key saved!")
            }
        }
    }

    // ==========================================
    // CLEAR DATA
    // ==========================================

    fun clearAllData() {
        prefs.clearAll()
        loadSettings()
        _saveResult.value = Pair(true, "All data cleared")
    }

    // ==========================================
    // FACTORY
    // ==========================================

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val prefs = SharedPrefsManager(context.applicationContext)
            return SettingsViewModel(prefs) as T
        }
    }
}