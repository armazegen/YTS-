package com.shortsai.app.api

import android.content.Context
import com.shortsai.app.utils.Constants
import com.shortsai.app.utils.SharedPrefsManager
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.Interceptor
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import com.google.gson.GsonBuilder

object ApiClient {

    // ==========================================
    // RETROFIT INSTANCES
    // ==========================================

    private var retrofit: Retrofit? = null
    private var apiKey: String = Constants.OPENAI_API_KEY

    // ==========================================
    // INITIALIZE WITH API KEY
    // ==========================================

    fun initialize(context: Context) {
        val prefs = SharedPrefsManager(context)
        apiKey = prefs.getApiKey()
        retrofit = buildRetrofit(apiKey)
    }

    fun updateApiKey(newApiKey: String) {
        apiKey = newApiKey
        retrofit = buildRetrofit(newApiKey)
    }

    // ==========================================
    // BUILD RETROFIT
    // ==========================================

    private fun buildRetrofit(key: String): Retrofit {
        val gson = GsonBuilder()
            .setLenient()
            .create()

        return Retrofit.Builder()
            .baseUrl(Constants.OPENAI_BASE_URL)
            .client(buildOkHttpClient(key))
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    // ==========================================
    // BUILD OKHTTP CLIENT
    // ==========================================

    private fun buildOkHttpClient(key: String): OkHttpClient {

        // Logging interceptor (only in debug)
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        // Auth interceptor - adds API key to every request
        val authInterceptor = object : Interceptor {
            override fun intercept(chain: Interceptor.Chain): Response {
                val originalRequest = chain.request()
                val newRequest = originalRequest.newBuilder()
                    .header("Authorization", "Bearer $key")
                    .header("Content-Type", "application/json")
                    .build()
                return chain.proceed(newRequest)
            }
        }

        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(
                Constants.CONNECTION_TIMEOUT,
                TimeUnit.SECONDS
            )
            .readTimeout(
                Constants.READ_TIMEOUT,
                TimeUnit.SECONDS
            )
            .writeTimeout(
                Constants.WRITE_TIMEOUT,
                TimeUnit.SECONDS
            )
            .retryOnConnectionFailure(true)
            .build()
    }

    // ==========================================
    // SERVICE GETTERS
    // ==========================================

    fun getOpenAIService(): OpenAIService {
        return (retrofit ?: buildRetrofit(apiKey))
            .create(OpenAIService::class.java)
    }

    fun getDalleService(): DalleService {
        return (retrofit ?: buildRetrofit(apiKey))
            .create(DalleService::class.java)
    }

    fun getTTSService(): TTSService {
        return (retrofit ?: buildRetrofit(apiKey))
            .create(TTSService::class.java)
    }

    // ==========================================
    // RAW OKHTTP FOR BINARY RESPONSES (TTS)
    // ==========================================

    fun getRawOkHttpClient(key: String = apiKey): OkHttpClient {
        return buildOkHttpClient(key)
    }
}