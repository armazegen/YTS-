package com.shortsai.app.api

import com.shortsai.app.api.models.TTSRequest
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Streaming

interface TTSService {

    /**
     * Text-to-Speech endpoint
     * Returns raw audio bytes (mp3)
     * @Streaming prevents loading entire file into memory
     */
    @Streaming
    @POST("audio/speech")
    suspend fun generateSpeech(
        @Body request: TTSRequest
    ): Response<ResponseBody>
}