package com.shortsai.app.api

import android.content.Context
import android.util.Log
import com.shortsai.app.api.models.*
import com.shortsai.app.utils.Constants
import com.shortsai.app.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ImageApiHandler(
    private val dalleService: DalleService,
    private val context: Context
) {

    private val TAG = "ImageApiHandler"

    // ==========================================
    // GENERATE SINGLE IMAGE
    // ==========================================

    /**
     * Generate one image for a scene
     */
    suspend fun generateSceneImage(
        scene: SceneData,
        sceneIndex: Int,
        onProgress: ((String) -> Unit)? = null
    ): StepResult<String> {

        return try {
            onProgress?.invoke(
                "🎨 Generating image ${sceneIndex + 1}..."
            )

            Log.d(TAG, "Generating image for scene ${sceneIndex + 1}")
            Log.d(TAG, "Prompt: ${scene.visualDescription}")

            // Enhance prompt for better results
            val enhancedPrompt = Constants.enhanceImagePrompt(
                scene.visualDescription
            )

            // Build DALL-E request
            val request = ImageGenerationRequest(
                model = Constants.DALLE_MODEL,
                prompt = enhancedPrompt,
                n = 1,
                size = Constants.IMAGE_SIZE,
                quality = Constants.IMAGE_QUALITY,
                style = Constants.IMAGE_STYLE,
                responseFormat = "url"
            )

            // Make API call
            val response = dalleService.generateImage(request)

            if (response.isSuccessful) {
                val imageResponse = response.body()

                // Check for error in body
                if (imageResponse?.error != null) {
                    return StepResult.Error(
                        "Image API Error: ${imageResponse.error.message}"
                    )
                }

                // Get image URL
                val imageUrl = imageResponse
                    ?.data
                    ?.firstOrNull()
                    ?.url
                    ?: return StepResult.Error(
                        "No image URL in response"
                    )

                Log.d(TAG, "Image URL received: $imageUrl")

                // Download image to local file
                val imagePath = downloadAndSaveImage(
                    imageUrl = imageUrl,
                    sceneIndex = sceneIndex
                )

                if (imagePath != null) {
                    Log.d(TAG, "Image saved: $imagePath")
                    StepResult.Success(imagePath)
                } else {
                    StepResult.Error("Failed to download image")
                }

            } else {
                val code = response.code()
                val errorMsg = when (code) {
                    401 -> Constants.Errors.API_KEY_ERROR
                    429 -> Constants.Errors.QUOTA_ERROR
                    400 -> "Invalid image prompt. Try a different topic."
                    else -> "Image generation failed (HTTP $code)"
                }
                Log.e(TAG, "Image API error: $code - $errorMsg")
                StepResult.Error(errorMsg)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Image generation exception: ${e.message}")
            StepResult.Error(
                "Image error: ${e.localizedMessage}",
                e
            )
        }
    }

    // ==========================================
    // GENERATE ALL SCENE IMAGES
    // ==========================================

    /**
     * Generate images for ALL scenes sequentially
     * Returns list of local image file paths
     */
    suspend fun generateAllSceneImages(
        scenes: List<SceneData>,
        onProgress: ((Int, String) -> Unit)? = null
    ): StepResult<List<String>> {

        val imagePaths = mutableListOf<String>()
        val failedScenes = mutableListOf<Int>()

        scenes.forEachIndexed { index, scene ->
            val progressPercent = Constants.Progress.STEP_IMAGES_START +
                    ((index.toFloat() / scenes.size) *
                            (Constants.Progress.STEP_IMAGES_END -
                                    Constants.Progress.STEP_IMAGES_START)).toInt()

            onProgress?.invoke(
                progressPercent,
                "🎨 Creating image ${index + 1}/${scenes.size}..."
            )

            val result = generateSceneImage(
                scene = scene,
                sceneIndex = index
            )

            when (result) {
                is StepResult.Success -> {
                    imagePaths.add(result.data)
                    Log.d(TAG, "Scene ${index + 1} image ready")
                }
                is StepResult.Error -> {
                    Log.e(TAG, "Scene ${index + 1} failed: ${result.message}")
                    failedScenes.add(index)

                    // Use placeholder if image fails
                    val placeholder = createPlaceholderImage(index)
                    if (placeholder != null) {
                        imagePaths.add(placeholder)
                    }
                }
            }

            // Small delay to avoid rate limiting
            kotlinx.coroutines.delay(500)
        }

        return if (imagePaths.size >= scenes.size / 2) {
            // At least half images succeeded
            StepResult.Success(imagePaths)
        } else {
            StepResult.Error(
                "Too many images failed (${failedScenes.size}/${scenes.size})"
            )
        }
    }

    // ==========================================
    // DOWNLOAD AND SAVE IMAGE
    // ==========================================

    private suspend fun downloadAndSaveImage(
        imageUrl: String,
        sceneIndex: Int
    ): String? = withContext(Dispatchers.IO) {
        try {
            val imagesDir = FileUtils.getImagesDir(context)
            val fileName = FileUtils.generateImageFileName(sceneIndex)
            val imageFile = File(imagesDir, fileName)

            val success = FileUtils.downloadImageToFile(
                imageUrl = imageUrl,
                destFile = imageFile
            )

            if (success && FileUtils.isValidFile(imageFile)) {
                imageFile.absolutePath
            } else {
                null
            }

        } catch (e: Exception) {
            Log.e(TAG, "Download/save failed: ${e.message}")
            null
        }
    }

    // ==========================================
    // PLACEHOLDER IMAGE (FALLBACK)
    // ==========================================

    private suspend fun createPlaceholderImage(
        sceneIndex: Int
    ): String? = withContext(Dispatchers.IO) {
        try {
            val imagesDir = FileUtils.getImagesDir(context)
            val fileName = FileUtils.generateImageFileName(sceneIndex)
            val imageFile = File(imagesDir, fileName)

            // Create a simple colored bitmap as placeholder
            val bitmap = android.graphics.Bitmap.createBitmap(
                Constants.VIDEO_WIDTH,
                Constants.VIDEO_HEIGHT,
                android.graphics.Bitmap.Config.ARGB_8888
            )

            // Color based on scene index
            val colors = intArrayOf(
                0xFF1A1A2E.toInt(),
                0xFF16213E.toInt(),
                0xFF0F3460.toInt(),
                0xFF533483.toInt(),
                0xFF7B2FBE.toInt(),
                0xFFFF0050.toInt()
            )
            bitmap.eraseColor(colors[sceneIndex % colors.size])

            val saved = FileUtils.saveBitmapToFile(bitmap, imageFile)
            bitmap.recycle()

            if (saved) imageFile.absolutePath else null

        } catch (e: Exception) {
            Log.e(TAG, "Placeholder creation failed: ${e.message}")
            null
        }
    }
}