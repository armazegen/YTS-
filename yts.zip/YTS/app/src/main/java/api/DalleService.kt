package com.shortsai.app.api

import com.shortsai.app.api.models.ImageGenerationRequest
import com.shortsai.app.api.models.ImageGenerationResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface DalleService {

    /**
     * DALL-E Image Generation endpoint
     * Used for generating scene images
     */
    @POST("images/generations")
    suspend fun generateImage(
        @Body request: ImageGenerationRequest
    ): Response<ImageGenerationResponse>
}