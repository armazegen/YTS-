package com.shortsai.app.api.models

import com.google.gson.annotations.SerializedName

// ==========================================
// DALL-E IMAGE GENERATION REQUEST
// ==========================================

data class ImageGenerationRequest(
    @SerializedName("model")
    val model: String = "dall-e-3",

    @SerializedName("prompt")
    val prompt: String,

    @SerializedName("n")
    val n: Int = 1,             // Number of images (dall-e-3: max 1)

    @SerializedName("size")
    val size: String = "1024x1792",  // 9:16 for Shorts

    @SerializedName("quality")
    val quality: String = "standard", // standard or hd

    @SerializedName("style")
    val style: String = "vivid",     // vivid or natural

    @SerializedName("response_format")
    val responseFormat: String = "url"  // url or b64_json
)

// ==========================================
// DALL-E IMAGE GENERATION RESPONSE
// ==========================================

data class ImageGenerationResponse(
    @SerializedName("created")
    val created: Long?,

    @SerializedName("data")
    val data: List<ImageData>?,

    @SerializedName("error")
    val error: ApiError?
)

data class ImageData(
    @SerializedName("url")
    val url: String?,

    @SerializedName("b64_json")
    val b64Json: String?,

    @SerializedName("revised_prompt")
    val revisedPrompt: String?
)

// ==========================================
// APP STATE MODELS
// ==========================================

/**
 * Represents overall generation state
 */
sealed class GenerationState {
    object Idle : GenerationState()
    data class Loading(
        val progress: Int,
        val message: String
    ) : GenerationState()
    data class Success(
        val videoPath: String,
        val videoScript: VideoScript
    ) : GenerationState()
    data class Error(
        val message: String,
        val throwable: Throwable? = null
    ) : GenerationState()
}

/**
 * Represents each step result
 */
sealed class StepResult<T> {
    data class Success<T>(val data: T) : StepResult<T>()
    data class Error<T>(
        val message: String,
        val throwable: Throwable? = null
    ) : StepResult<T>()
}

/**
 * Video generation data holder
 */
data class VideoGenerationData(
    val topic: String,
    val script: VideoScript? = null,
    val imagePaths: List<String> = emptyList(),
    val audioPath: String = "",
    val outputVideoPath: String = "",
    val isComplete: Boolean = false
)