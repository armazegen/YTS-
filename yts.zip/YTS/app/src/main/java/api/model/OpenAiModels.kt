package com.shortsai.app.api.models

import com.google.gson.annotations.SerializedName

// ==========================================
// CHAT COMPLETION REQUEST
// ==========================================

data class ChatRequest(
    @SerializedName("model")
    val model: String,

    @SerializedName("messages")
    val messages: List<ChatMessage>,

    @SerializedName("max_tokens")
    val maxTokens: Int = 2000,

    @SerializedName("temperature")
    val temperature: Double = 0.8,

    @SerializedName("response_format")
    val responseFormat: ResponseFormat? = null
)

data class ChatMessage(
    @SerializedName("role")
    val role: String,           // "system", "user", "assistant"

    @SerializedName("content")
    val content: String
)

data class ResponseFormat(
    @SerializedName("type")
    val type: String = "json_object"
)

// ==========================================
// CHAT COMPLETION RESPONSE
// ==========================================

data class ChatResponse(
    @SerializedName("id")
    val id: String?,

    @SerializedName("object")
    val objectType: String?,

    @SerializedName("created")
    val created: Long?,

    @SerializedName("model")
    val model: String?,

    @SerializedName("choices")
    val choices: List<ChatChoice>?,

    @SerializedName("usage")
    val usage: TokenUsage?,

    @SerializedName("error")
    val error: ApiError?
)

data class ChatChoice(
    @SerializedName("index")
    val index: Int?,

    @SerializedName("message")
    val message: ChatMessage?,

    @SerializedName("finish_reason")
    val finishReason: String?
)

data class TokenUsage(
    @SerializedName("prompt_tokens")
    val promptTokens: Int?,

    @SerializedName("completion_tokens")
    val completionTokens: Int?,

    @SerializedName("total_tokens")
    val totalTokens: Int?
)

data class ApiError(
    @SerializedName("message")
    val message: String?,

    @SerializedName("type")
    val type: String?,

    @SerializedName("code")
    val code: String?
)

// ==========================================
// TTS REQUEST
// ==========================================

data class TTSRequest(
    @SerializedName("model")
    val model: String,          // "tts-1" or "tts-1-hd"

    @SerializedName("input")
    val input: String,          // Text to convert

    @SerializedName("voice")
    val voice: String,          // alloy, echo, fable, onyx, nova, shimmer

    @SerializedName("response_format")
    val responseFormat: String = "mp3",

    @SerializedName("speed")
    val speed: Double = 1.0     // 0.25 to 4.0
)

// ==========================================
// PARSED SCRIPT MODEL
// ==========================================

data class VideoScript(
    @SerializedName("title")
    val title: String = "",

    @SerializedName("hook")
    val hook: String = "",

    @SerializedName("script")
    val script: String = "",

    @SerializedName("scenes")
    val scenes: List<SceneData> = emptyList(),

    @SerializedName("hashtags")
    val hashtags: List<String> = emptyList(),

    @SerializedName("call_to_action")
    val callToAction: String = ""
)

data class SceneData(
    @SerializedName("scene_number")
    val sceneNumber: Int = 0,

    @SerializedName("duration")
    val duration: Int = 5,          // seconds

    @SerializedName("narration")
    val narration: String = "",

    @SerializedName("visual_description")
    val visualDescription: String = "",

    @SerializedName("on_screen_text")
    val onScreenText: String = "",

    // Runtime properties (not from JSON)
    var imagePath: String = "",
    var imageUrl: String = ""
)