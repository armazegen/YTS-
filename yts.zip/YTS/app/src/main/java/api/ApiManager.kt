package com.shortsai.app.api

import android.content.Context
import android.util.Log
import com.shortsai.app.api.models.*
import com.shortsai.app.utils.Constants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Central manager that coordinates all API calls
 * Script → Images → Audio
 */
class ApiManager(private val context: Context) {

    private val TAG = "ApiManager"

    // ==========================================
    // HANDLERS
    // ==========================================

    private val scriptHandler = ScriptApiHandler(
        ApiClient.getOpenAIService()
    )

    private val imageHandler = ImageApiHandler(
        ApiClient.getDalleService(),
        context
    )

    private val audioHandler = AudioApiHandler(
        ApiClient.getTTSService(),
        context
    )

    // ==========================================
    // MAIN GENERATION FLOW
    // ==========================================

    /**
     * Complete generation pipeline as Flow
     * Emits GenerationState updates throughout
     */
    fun generateVideoContent(topic: String): Flow<GenerationState> = flow {

        // Emit initial loading
        emit(GenerationState.Loading(
            progress = 5,
            message = "🚀 Starting generation..."
        ))

        // ==============================
        // STEP 1: GENERATE SCRIPT
        // ==============================
        Log.d(TAG, "=== STEP 1: Script Generation ===")

        emit(GenerationState.Loading(
            progress = Constants.Progress.STEP_SCRIPT,
            message = Constants.Progress.MSG_SCRIPT
        ))

        val scriptResult = scriptHandler.generateVideoScript(topic)

        if (scriptResult is StepResult.Error) {
            emit(GenerationState.Error(scriptResult.message))
            return@flow
        }

        val videoScript = (scriptResult as StepResult.Success).data
        Log.d(TAG, "Script ready: ${videoScript.title}")

        // ==============================
        // STEP 2: GENERATE IMAGES
        // ==============================
        Log.d(TAG, "=== STEP 2: Image Generation ===")

        val imagePaths = mutableListOf<String>()

        videoScript.scenes.forEachIndexed { index, scene ->
            val progress = Constants.Progress.STEP_IMAGES_START +
                    ((index.toFloat() / videoScript.scenes.size) *
                            (Constants.Progress.STEP_IMAGES_END -
                                    Constants.Progress.STEP_IMAGES_START)).toInt()

            emit(GenerationState.Loading(
                progress = progress,
                message = "🎨 Image ${index + 1}/${videoScript.scenes.size}..."
            ))

            val imageResult = imageHandler.generateSceneImage(
                scene = scene,
                sceneIndex = index
            )

            when (imageResult) {
                is StepResult.Success -> {
                    imagePaths.add(imageResult.data)
                    // Update scene with local path
                    scene.imagePath = imageResult.data
                }
                is StepResult.Error -> {
                    Log.w(TAG, "Image ${index + 1} failed: ${imageResult.message}")
                    // Continue with placeholder
                }
            }

            // Rate limit protection
            if (index < videoScript.scenes.size - 1) {
                kotlinx.coroutines.delay(800)
            }
        }

        if (imagePaths.isEmpty()) {
            emit(GenerationState.Error("All image generations failed"))
            return@flow
        }

        Log.d(TAG, "Images ready: ${imagePaths.size}")

        // ==============================
        // STEP 3: GENERATE AUDIO
        // ==============================
        Log.d(TAG, "=== STEP 3: Audio Generation ===")

        emit(GenerationState.Loading(
            progress = Constants.Progress.STEP_AUDIO,
            message = Constants.Progress.MSG_AUDIO
        ))

        // Build full script text
        val fullScript = audioHandler.buildFullScriptWithHook(
            hook = videoScript.hook,
            scenes = videoScript.scenes,
            callToAction = videoScript.callToAction
        )

        val audioResult = audioHandler.generateVoiceover(
            script = fullScript
        )

        val audioPath = when (audioResult) {
            is StepResult.Success -> audioResult.data
            is StepResult.Error -> {
                Log.e(TAG, "Audio failed: ${audioResult.message}")
                emit(GenerationState.Error(audioResult.message))
                return@flow
            }
        }

        Log.d(TAG, "Audio ready: $audioPath")

        // ==============================
        // EMIT SUCCESS WITH ALL DATA
        // ==============================
        emit(GenerationState.Loading(
            progress = Constants.Progress.STEP_VIDEO_BUILD,
            message = Constants.Progress.MSG_VIDEO
        ))

        // Update scenes with image paths
        videoScript.scenes.forEachIndexed { index, scene ->
            if (index < imagePaths.size) {
                scene.imagePath = imagePaths[index]
            }
        }

        Log.d(TAG, "=== ALL API STEPS COMPLETE ===")
        Log.d(TAG, "Script: ${videoScript.title}")
        Log.d(TAG, "Images: ${imagePaths.size}")
        Log.d(TAG, "Audio: $audioPath")

        // Return success with all data needed for video building
        emit(GenerationState.Success(
            videoPath = audioPath,       // Temp: will be replaced by FFmpeg output
            videoScript = videoScript
        ))
    }

    // ==========================================
    // INDIVIDUAL GETTERS (FOR REPOSITORY)
    // ==========================================

    fun getScriptHandler() = scriptHandler
    fun getImageHandler() = imageHandler
    fun getAudioHandler() = audioHandler
}